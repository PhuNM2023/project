export const Colors = {
    'red':'#f44336',
    'blue':'#03a9f4',
    'grey':'#9e9e9e',
    'pink':'#e91e63',
    'silver':'#f5f5f5',
    'yellow':'#ffeb3b',
    'brown':'#795548',
    'green':'#76ff03',
}