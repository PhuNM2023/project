export const settingSlideHeader = {
    dots: true,
    arrows : false,
    infinite: true,
    autoplay: true,
    speed: 300,
    autoplaySpeed: 3000, 
    slidesToShow: 1, 
    slidesToScroll: 1, 
  };