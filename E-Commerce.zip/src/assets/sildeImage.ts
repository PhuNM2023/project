export const slideImages = [
    { url: 'https://cdn.tgdd.vn/Files/News/2022/06/08/Cover-1200x628.jpg' ,
      title:"A new line of overalls for the little ones",
      body:"How can you evaluate content without design? No typography,no colors, no layout, no styles, all those things that convey the important signals." },
    { url: 'https://www.acfc.com.vn/wp/wp-content/uploads/2021/11/cach-chon-quan-ao-cho-tre-so-sinh-4.jpg',
       title:"New and comfortable growsuite for your baby",
      body:"It’s content strategy gone awry right from the start. Forswearing the use of Lorem Ipsum wouldn’t have helped, won’t help now every other."},
    { url: 'https://monkeymedia.vcdn.com.vn/upload/web/storage_web/28-03-2022_17:49:00_do-choi-thong-minh-cho-be-6-thang-tuoi-0.jpg',
      title:"Toys and accessories",
      body:"A seemingly elegant design can quickly begin to bloat with unexpected content or break under the weight of actual activity layout living." },
  ];