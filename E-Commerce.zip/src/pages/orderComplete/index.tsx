import * as React from 'react';

export interface IOrderCompleteProps {
}

export default function OrderComplete (props: IOrderCompleteProps) {
  return (
    <div>
      OrderComplete
    </div>
  );
}
