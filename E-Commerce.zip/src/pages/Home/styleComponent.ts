export   const divStyle = {
    display: 'flex',
    alignItem: 'center',
    justifyContent: 'center',
    height: '730px',
    backgroundSize: 'cover',
    position:"relative",
  }